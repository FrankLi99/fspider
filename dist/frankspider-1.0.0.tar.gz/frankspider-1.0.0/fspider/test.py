# -*- coding: utf-8 -*-
__author__ = 'Frank Li'

def my_print():
    print('just a test pypi upload...')

if __name__ == '__main__':
    my_print()