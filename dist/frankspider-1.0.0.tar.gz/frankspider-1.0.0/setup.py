from setuptools import find_packages, setup
setup(
    name='frankspider',
    version='1.0.0',
    description='a spider tool',
    author='frank',
    author_email='frank@gmail.com',
    url='https://github.com/the0demiurge/ShadowSocksShare',
    #packages=find_packages(),
    packages=['fspider'],
    #install_requires=['requests'],
)
